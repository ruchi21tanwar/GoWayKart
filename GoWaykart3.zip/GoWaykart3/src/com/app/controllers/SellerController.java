package com.app.controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.BindException;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Product;
import com.app.pojos.Seller;
import com.app.services.SellerService;

@Controller
@RequestMapping("/seller")
public class SellerController {
	@Autowired
	private SellerService service;

	@Value("${upload_image_path}")
	private String imagePath;

	@PostConstruct
	public void init() {
		System.out.println("in init " + service);
	}

	@GetMapping("/register")
	public String showRegisterForm(Seller s) {
		System.out.println("in register for get mapping" + service);
		return "seller/register";
	}

	@PostMapping("/register")
	public String processRegisterForm(@Valid Seller s, BindingResult res,RedirectAttributes att,  HttpSession hs) {
		if (res.hasErrors()) {
			return "seller/register";
		}
		String sts;
		try {
			sts = service.registerSeller(s);
		} catch (Exception e) {
			sts = "Registration Failed";
		}
		if (sts.equals("Registration Failed")) {
			att.addFlashAttribute("status", sts);
			return "seller/register";
		}
		hs.setAttribute("status", sts);
		hs.setAttribute("current_seller", s);
		return "redirect:/seller/sellerPanel";
	}

	@GetMapping("/login")
	public String showLoginForm(Seller s) {
		System.out.println("show login form ");
		return "seller/login";
	}

	@PostMapping("/login")
	public String processLoginForm(@Valid Seller s, BindingResult res, RedirectAttributes att, HttpSession hs) {
		if (res.hasFieldErrors("email") || res.hasFieldErrors("password")) {
			return "seller/login";
		}
		String sts = service.validateUser(s.getEmail(), s.getPassword());
		if (sts.equals("Invalid Username and Password")) {
			att.addFlashAttribute("status", sts);
			return "seller/login";
		}
		hs.setAttribute("current_seller", s);
		return "redirect:/seller/sellerPanel";
	}

	@GetMapping("/sellerPanel")
	public String showSellerHome() {
		return "seller/sellerPanel";
	}

	@GetMapping("/contact")
	public String contactAdmin() {
		return "seller/contact";
	}

	@GetMapping("/Products")
	public String addingProduct(Model map) {
		System.out.println("in list products" + map.getClass().getName());
		List<Product>l1=service.listProduct();
		System.out.println("prod list "+l1);
		map.addAttribute("prod_list", l1);

		System.out.println("in list images " + imagePath);
		File uploadLocationDir = new File(imagePath);
		System.out.println(uploadLocationDir.exists() + " " + uploadLocationDir.isDirectory() + " "
				+ uploadLocationDir.getAbsolutePath());

		String[] files = uploadLocationDir.list();
		System.out.println("files " + Arrays.toString(files));
		map.addAttribute("image_list", files);

		return "seller/Products";
	}

	@GetMapping("/addProduct")
	public String showAddProductForm(Model m, HttpSession hs) {
		m.addAttribute("seller", new Product());
		Seller s = (Seller) hs.getAttribute("current_seller");
		if (s == null) {
			return "seller/login";
		}
		System.out.println("hi i m here i show add product form in get mapping");
		
		return "seller/addProduct";
	}

	@PostMapping("/addProduct")
	public String processaddProduct(@Valid @ModelAttribute("seller") Product p, BindingResult rsp,@RequestParam("productImage") MultipartFile file,
			HttpServletRequest request, Model map, HttpSession hs,  RedirectAttributes attr) {
		String uploadLocation = imagePath;
		System.out.println("desrve");
		System.out.println(
				"in upload file " + file.getOriginalFilename() + " size " + file.getSize() + " " + uploadLocation);
		try {
			File dest = new File(uploadLocation, file.getOriginalFilename());
			// file transferred to server side folder
			file.transferTo(dest);
			//IMPORTANT --assigning product image name here
			p.setproductImage(file.getOriginalFilename());
		} catch (Exception e) {
			map.addAttribute("mesg", "File upload failed : " + e.getMessage());
			return "seller/addProduct";
		}
		service.addProduct(p);
		/*
		 * Understand -- there will be binding errors on some of the fields.
		 * So do field specific err checking hasFieldError(String fieldName)
		 * Another question -- why invalidate the session ? I dont think its necessary 
		 * but u pls check!
		 */
	/*	if (rsp.hasErrors()) {
			System.out.println("Ifff");
			attr.addAttribute("status", "Invalid Entry");
			return "seller/addProduct";
		}
		hs.invalidate();*/
		
		attr.addAttribute("mesg", "Successful addition of product");
		System.out.println("target");
		return "redirect:Products";
	}

	// show update form
	@GetMapping(value = "/update")
	public String showUpdateForm(@RequestParam int id, Model map) {
		System.out.println("in show update form " + id);
		map.addAttribute("Product", service.getProductById(id));// detached
		return "seller/update";
	}

	// req handling method to process update form
	@PostMapping(value = "/update")
	public String processUpdateForm(
			/* HttpServletRequest rq, @RequestParam int id, */ RedirectAttributes attrs, @Valid Product p1,
			BindingResult res) {
		System.out.println("in proc update form " + " " + p1);
		if (res.hasErrors()) {
			System.out.println("p.l errs : processing reg form " + res);
			return "seller/update";
		}
		// c1.setId(id);
		System.out.println("in process update form , no pl errs " + p1);
		attrs.addAttribute("status", service.updateProduct(p1));
		return "redirect:/seller/Products";
	}

	// req handling method to delete customer details
	@GetMapping(value = "/delete/{prodId}")
	public String processUpdateForm(@PathVariable int productId, RedirectAttributes attrs) {

		System.out.println("in delete product  " + productId);
		attrs.addAttribute("status", service.deleteProduct(productId));
		return "redirect:/seller/Products";
	}

	@ModelAttribute("productCategory")
	public Map<String, String> getProductCatList() {
		Map<String, String> pc = new HashMap<String, String>();
		pc.put("Laptops,Games & Accessories", "Laptops,Games & Accessories");
		pc.put("Home & Furniture", "Home & Furniture");
		pc.put("Fashion", "Fashion");
		pc.put("TV & Appliances", "TV & Appliances");
		pc.put("Books", "Books");
		pc.put("Mobile & Accessories", "Mobile & Accessories");
		pc.put("Food & Nutrition", "Food & Nutrition");
		pc.put("HealthCare", "HealthCare");
		pc.put("Sports", "Sports");
		pc.put("Household Supplies", "Household Supplies");
		pc.put("Lighting & Home Decor", "Lighting & Home Decor");

		return pc;
	}

	@ModelAttribute("productUser")
	public Map<String, String> getProUserList() {
		Map<String, String> pu = new HashMap<String, String>();
		pu.put("Mens", "Mens");
		pu.put("Womens", "Womens");
		pu.put("Baby & Kids", "Baby & Kids");
		pu.put("Boys", "Boys");
		pu.put("Girls", "Girls");
		return pu;
	}

}