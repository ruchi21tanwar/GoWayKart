package com.app.controllers;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Admin;
import com.app.services.AdminService;

@Controller
@RequestMapping("/admin")
public class AdminController
{
	@Autowired
	private AdminService service;
	
	@PostConstruct
	public void init() 
	{
		System.out.println("in init ");
	}
	
	@GetMapping("/login")
	public String showLoginForm(Admin s)
	{
		System.out.println("show login form ");
		return "admin/login";
	}
	
	@PostMapping("/login")
	public String processLoginForm(@Valid Admin s,BindingResult res,RedirectAttributes att,HttpSession hs)	
	{
		if(res.hasErrors())
		{
			System.out.println("error in field");
			return "admin/login";
		}
		String sts=service.validateAdmin(s);
		if(sts.equals("Invalid Username and Password"))
		{
			System.out.println("invalid match");
			att.addFlashAttribute("status",sts);
			return "redirect:login";
		}
		hs.setAttribute("status", sts);
		hs.setAttribute("current_Admin",s);
		return "redirect:adminPanel";
	}
	
	@GetMapping("/adminPanel")
	public String showAdminPanel()
	{
		return "admin/adminPanel";
	}
	
	
	/*@GetMapping("/listOfUsers")
	public String listOfUsers(Model map,RedirectAttributes att)
	{
		System.out.println("in list users"+map.getClass().getName());
		map.addAttribute("user_list", service.listUser());
		return "redirect:listOfUser";
	}
	
	@GetMapping("/listOfSellers")
	public String listOfSellers(Model map,RedirectAttributes att)
	{
		System.out.println("in list sellers"+map.getClass().getName());
		map.addAttribute("seller_list", service.listSeller());
		return "redirect:listOfSeller";
	}
	
	@GetMapping("/listOfProducts")
	public String listOfProducts(Model map,RedirectAttributes att)
	{
		System.out.println("in list products"+map.getClass().getName());
		map.addAttribute("product_list", service.listProduct());
		return "redirect:listOfProducts";
	}
	
	@GetMapping(value = "/delete/{userId}")
	public String processDeleteUser(@PathVariable int userId, RedirectAttributes attrs) 
	{
		System.out.println("in delete user  " + userId);
		attrs.addFlashAttribute("status", service.deleteUser(userId));
		return "redirect:list";
	}
	
	@GetMapping(value = "/delete/{sellerId}")
	public String processDeleteSeller(@PathVariable int sellerId, RedirectAttributes attrs) 
	{
		System.out.println("in delete seller  " + sellerId);
		attrs.addFlashAttribute("status", service.deleteSeller(sellerId));
		return "redirect:seller";
	}
	
	@GetMapping(value = "/delete/{productId}")
	public String processDeleteProduct(@PathVariable int productId, RedirectAttributes attrs) 
	{
		System.out.println("in delete product  " + productId);
		attrs.addFlashAttribute("status", service.deleteUser(productId));
		return "redirect:product";
	}
	*/
	
	
	

}
