package com.app.controllers;


import javax.annotation.PostConstruct;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.User;
import com.app.services.UserService;

@Controller
@RequestMapping("/user")
public class UserController
{
	@Autowired
	private UserService service;
	
	@PostConstruct
	public void init()
	{
		System.out.println("IN INIT OF USER CONTROLLER"+service);
	}
	
	@GetMapping("/register")
	public String showRegisterForm(User u)
	{
		System.out.println("in register -> get mapping"+service);
		return "user/register";
	}
	
	@PostMapping("/register")
	public String processRegisterform(@Valid User u, BindingResult res, RedirectAttributes att, HttpSession hs )
	{
		if(res.hasErrors())
		{
			return "user/register";
		}
		String sts;
			try
			{
				sts = service.registerUser(u);
			}
			catch (Exception e) 
			{
				sts="Registration failed";
				e.printStackTrace();
			}
		if(sts.equals("Registration failed"))
		{
			att.addFlashAttribute("status", sts);
			return "redirect:/register";
		}
		hs.setAttribute("current_user",u);
		hs.setAttribute("status", sts);
		return "redirect:/userPanel";
	}

	@GetMapping("/login")
	public String showLogin(User u)
	{
		System.out.println("Show Login Page");
		return "user/login";
	}
	
	@PostMapping("/login")
	public String processLoginForm(@Valid User u, BindingResult rep, RedirectAttributes attr, HttpSession hs)
	{
		if(rep.hasFieldErrors("email")||rep.hasFieldErrors("password"))
		{
			System.out.println("error in field");
			return "user/login";
		}
		String sts=service.validateUser(u);
		if(sts.equals("Invalid Username and Password"))
		{
			System.out.println("invalid u and p");
			attr.addFlashAttribute("status",sts);
			return "redirect:/login";
		}
		hs.setAttribute("current_user",u);
		hs.setAttribute("status", sts);
		return "redirect:/userPanel";
	}
	
	@GetMapping("/userPanel")
	public String showUserPanel()
	{
		System.out.println("in show userpanel ");
		return "user/userPanel";
	}
	
	
}
