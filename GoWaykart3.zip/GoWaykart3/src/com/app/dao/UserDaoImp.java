package com.app.dao;

import javax.persistence.NoResultException;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.app.pojos.User;

@Repository
public class UserDaoImp implements UserDao
{

	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	public User validateUser(User u) 
	{
		
		try 
		{
			return (User) sessionFactory.getCurrentSession().
					createQuery("select u from User u where u.email=:em and u.password=:pass")
					.setParameter("em", u.getEmail()).setParameter("pass", u.getPassword()).getSingleResult();
		}
		catch (NoResultException e) 
		{
			return null;
		}
	}

	@Override
	public User registerUser(User u) 
	{
		Session hs= sessionFactory.getCurrentSession();
			try 
			{
				return (User) hs.merge(u);
			} 
			catch (Exception e) 
			{
				throw e;
			}	
	}

}
