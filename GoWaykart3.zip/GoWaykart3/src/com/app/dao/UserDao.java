package com.app.dao;

import com.app.pojos.User;

public interface UserDao 
{
	User validateUser(User u);

	User registerUser(User u);
}
