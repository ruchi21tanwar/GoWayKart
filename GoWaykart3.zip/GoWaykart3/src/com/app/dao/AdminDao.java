package com.app.dao;

import com.app.pojos.Admin;

public interface AdminDao 
{
	Admin validateAdmin(Admin s);
	/*List<User> listUser();
	List<Seller> listSeller();
	List<Product> listProduct();
	String deleteUser(Integer userId);
	String deleteSeller(Integer sellerId);
	String deleteProduct(Integer productId);*/
}
