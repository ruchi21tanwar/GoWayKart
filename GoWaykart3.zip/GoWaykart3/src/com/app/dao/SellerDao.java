package com.app.dao;


import java.util.List;
import com.app.pojos.Product;
import com.app.pojos.Seller;

public interface SellerDao 
{
	Seller validateUser(String email, String password);

	Seller registerSeller(Seller s);	
	
	List<Product> listProduct();
	Product updateProduct(Product p);
	String deleteProduct(Integer id);
	Product addProduct(Product p);
	
	Product getProductById(Integer id);
}
