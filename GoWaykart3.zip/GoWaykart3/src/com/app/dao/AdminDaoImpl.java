package com.app.dao;



import javax.persistence.NoResultException;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Admin;

@Repository
public class AdminDaoImpl implements AdminDao
{
	@Autowired
	private SessionFactory factory;

	@Transactional
	@Override
	public Admin validateAdmin(Admin a) 
	{
		System.out.println("in dao");
		try
		{
		  return (Admin) factory.getCurrentSession().createQuery("select s from Admin s where s.email=:em and s.password=:pass",Admin.class).setParameter("em", a.getEmail()).setParameter("pass", a.getPassword()).getSingleResult();
		}
		catch(NoResultException e)
		{
			return null;
		}
		
	}

	/*@Override
	public List<User> listUser()
	{
		return factory.getCurrentSession()
				.createQuery("select u from User u",User.class).getResultList();
	}

	@Override
	public List<Seller> listSeller() 
	{
		return factory.getCurrentSession()
				.createQuery("select s from Seller s",Seller.class).getResultList();
	}

	@Override
	public List<Product> listProduct() 
	{
		return factory.getCurrentSession()
				.createQuery("select p from Product p",Product.class).getResultList();
		
	}

	@Override
	public String deleteUser(Integer userId)
	{
		String status="User deletion failed";
		User u=getUserById(userId);
		if(u != null) 
		{
			factory.getCurrentSession().delete(u);
			status="User with ID "+u.getUserId()+" deleted successfully";
		}
		return status;
		
	}

	@Override
	public String deleteSeller(Integer sellerId) 
	{
		String status="Seller deletion failed";
		Seller s=getSellerById(sellerId);
		if(s != null) 
		{
			factory.getCurrentSession().delete(s);
			status="Seller with ID "+s.getSeller_id()+" deleted successfully";
		}
		return status;
	}

	@Override
	public String deleteProduct(Integer productId) 
	{
		String status="Product deletion failed";
		Product p=getProductById(productId);
		if(p != null) 
		{
			factory.getCurrentSession().delete(p);
			status="Customer with ID "+p.getProductId()+" deleted successfully";
		}
		return status;
	}

	public User getUserById(Integer userId)
	{
		return (User) factory.getCurrentSession().get(User.class, userId);
	}
	
	public Seller getSellerById(Integer sellerId)
	{
		return (Seller) factory.getCurrentSession().get(Seller.class, sellerId);
	}
	
	public Product getProductById(Integer productId)
	{
		return (Product) factory.getCurrentSession().get(Product.class, productId);
	}
*/
}

