package com.app.dao;

import javax.persistence.NoResultException;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Seller;
import java.util.List;

import com.app.pojos.Product;
@Repository
public class SellerDaoImpl implements SellerDao
{
	@Autowired
	private SessionFactory factory;

	@Override
	public Seller validateUser(String email, String password) 
	{
		try
		{
			return (Seller) factory.getCurrentSession().
				createQuery("select s from Seller s where s.email=:em and s.password=:pass")
				.setParameter("em", email).setParameter("pass", password).getSingleResult();
		}
		catch(NoResultException e)
		{
			return null;
		}
		
	}

	@Override
	public Seller registerSeller(Seller s) 
	{
		try
		{
		  return (Seller) factory.getCurrentSession().merge(s);
		}
		catch(Exception e)
		{
			throw e;
		}
	}
	
	
	@Override
	public String deleteProduct(Integer id)
	{

		String status="Product deletion failed";
		Product p=getProductById(id);
		if(p != null) {
			factory.getCurrentSession().delete(p);
			status="Product with ID "+p.getProductId()+" deleted successfully";
		}
		return status;
	}
	
	@Override
	public Product addProduct(Product p) {
		System.out.println("Dao : add product "
				+ factory.getCurrentSession().save(p));
		return p;
	}

	//@SuppressWarnings("unchecked")
	@Override
	public List<Product> listProduct() {
			return factory.getCurrentSession().createQuery("select p from Product p",Product.class).getResultList();
		}

	@Override
	public Product updateProduct(Product p) {

		factory.getCurrentSession().update(p);
		return p;
	}

	@Override
	public Product getProductById(Integer id) {
		return (Product) factory.getCurrentSession().get(Product.class, id);
	}


}
