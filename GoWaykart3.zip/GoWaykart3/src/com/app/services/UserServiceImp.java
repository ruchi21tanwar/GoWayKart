package com.app.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.UserDao;
import com.app.pojos.User;

@Service
@Transactional
public class UserServiceImp implements UserService 
{

	@Autowired
	private UserDao dao;
	
	
	@Override
	public String registerUser(User u) 
	{
		User user;
		try {
			user = dao.registerUser(u);
		} catch (Exception e) {
			throw e;
			
		}
		if(user==null)
			{
				System.out.println("jkgsgj sgjks, jkgsljg sjkgsjg sjgkjks gjk");	
				return "Registration failed";
			}
		return "Registration successfull"+user;
	}
	
	
	
	@Override
	public String validateUser(User u) 
	{
		User user=dao.validateUser(u);
		if(user==null)
		{
			
			return "Invalid Username and Password";
		}
		return "Successfully login: "+user;
	}

	

}
