package com.app.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.SellerDao;
import com.app.pojos.Seller;
import java.util.List;

import com.app.pojos.Product;

@Service
@Transactional
public class SellerServiceImpl implements SellerService
{
	@Autowired
	private SellerDao dao;

	@Override
	public String validateUser(String email, String password) 
	{		
		Seller s=dao.validateUser(email,password);
		if(s==null)
		{
			return "Invalid Username and Password";
		}
		return "Successfully login: "+s;
	}

	@Override
	public String registerSeller(Seller s) 
	{
		Seller seller;
		try 
		{
			seller = dao.registerSeller(s);
		} 
		catch (Exception e) 
		{
			throw e;
		}
		if(seller==null)
		{
			return "Registration Failed";
		}
		return "Registration Successfull"+s;
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<Product> listProduct()
	 {
		return dao.listProduct();
	 }
	
	@Override
	public String updateProduct(Product p)
	{
		 dao.updateProduct(p);
		 return "Product with ID "+p.getProductId()+" Updated successfully";
	}
	
	@Override
	public String deleteProduct(Integer id)
	{
		
		return dao.deleteProduct(id);
	}
	
	@Override
	public String addProduct(Product p)
	{
		dao.addProduct(p);
		return "Product with ID "+p.getProductId() +" added successfully";
	}
	
	@Override
	public Product getProductById(Integer id)
	{
		return dao.getProductById(id);
		
	}
}
