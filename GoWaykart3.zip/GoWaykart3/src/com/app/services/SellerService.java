package com.app.services;

import com.app.pojos.Seller;
import java.util.List;
import com.app.pojos.Product;

public interface SellerService 
{

	 String validateUser(String email, String password);

	String registerSeller(Seller s);
	
	 List<Product> listProduct();
		String updateProduct(Product p);
		String deleteProduct(Integer id);
		String addProduct(Product p);
		
		Product getProductById(Integer id);
	
	
}
