package com.app.services;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.AdminDao;
import com.app.pojos.Admin;

@Service
@Transactional
public class AdminServiceImpl implements AdminService 
{
	@Autowired
	private AdminDao dao;

	@Override
	public String validateAdmin(Admin s) 
	{		
		Admin a=dao.validateAdmin(s);
		System.out.println("in service 1");
		if(a==null)
		{
			System.out.println("in service 2");
			return "Invalid Username and Password";
		}
		return "Successfully login: "+s;
	}

	/*@Override
	public List<User> listUser()
	{
		return dao.listUser();
	}

	@Override
	public List<Seller> listSeller()
	{
		return dao.listSeller();
	}

	@Override
	public List<Product> listProduct() 
	{
		return dao.listProduct();
	}

	@Override
	public String deleteUser(Integer userId) 
	{
		return dao.deleteUser(userId);
	}

	@Override
	public String deleteSeller(Integer sellerId) 
	{
		return dao.deleteSeller(sellerId);
	}

	@Override
	public String deleteProduct(Integer productId)
	{
		return dao.deleteProduct(productId);
	}*/

	
}
