package com.app.services;

import com.app.pojos.User;

public interface UserService 
{
	String registerUser(User u);
	
	
	
	String validateUser(User u);

	
}
