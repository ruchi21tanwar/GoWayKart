package com.app.services;

import com.app.pojos.Admin;

public interface AdminService
{
	 String validateAdmin(Admin s);
	/* List<User> listUser();
	 List<Seller> listSeller();
	 List<Product> listProduct();
	 String deleteUser(Integer userId);
	 String deleteSeller(Integer sellerId);
	 String deleteProduct(Integer productId);*/
}
