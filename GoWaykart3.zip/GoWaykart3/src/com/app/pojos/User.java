package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="MyUser")
public class User 
{
	//data members
	private Integer userId;
	
	@NotEmpty(message="* Name Must not be null")
	private String userName;
	@NotEmpty(message="* Password must not be null")
	private String password;
	@NotEmpty(message="* Address must not be null")
	private String address;
	@NotEmpty(message="* Email must not be null")
	@Email(message="* Invalid Email")
	private String email;
	
	@NotEmpty(message="* Phone number must not be null")
	private String phoneNo;
	private String shippingInfo;
	@NotEmpty(message="* Select Gender")
	private String gender;
	private String verification;
	
	//constructors
	public User()
	{
		super();
	}
	public User(String userName, String password, String address, String email, String phoneNo, String gender) {
		super();
		this.userName = userName;
		this.password = password;
		this.address = address;
		this.email = email;
		this.phoneNo = phoneNo;
		this.gender = gender;
	}
	
	
	
	
	//getter and setter
	
	
	//toString
	@Override
	public String toString() {
		return "User [userName=" + userName + ", address=" + address + ", email=" + email + ", phoneNo=" + phoneNo
				+ ", gender=" + gender + "]";
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	@Column(name="email",unique=true,length=30)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(name="phoneno",unique=true,length=12)
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getShippingInfo() {
		return shippingInfo;
	}
	public void setShippingInfo(String shippingInfo) {
		this.shippingInfo = shippingInfo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getVerification() {
		return verification;
	}
	public void setVerification(String verification) {
		this.verification = verification;
	}
}
