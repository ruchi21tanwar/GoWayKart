package com.app.pojos;

import java.sql.Blob;
import java.util.Base64;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;
import org.springframework.web.multipart.commons.CommonsMultipartFile;


@Entity
@Table(name="Product")
public class Product
{
	//Data Members
	
	private Integer productId;
	private String sellerId;
	@NotEmpty(message=" * ")
	private String productName;
	
	@NumberFormat(style=Style.NUMBER)
	private int productQuantity;
		
	@NumberFormat(style=Style.NUMBER)
	private int productPrice;
	@NotEmpty(message=" * Choose Category")
	private String productCategory;

	private String productImage;
	private CommonsMultipartFile fileData;
	@NotEmpty(message=" * Choose A Product User Type")
	private String productUser;
	//private String base64;
	
	//Constructor
	public Product()
	{
		super();
	}
	public Product(String productName, int productQuantity, int productPrice, String productCategory,
			String productImage, String productUser) 
	{
		super();
		this.productName = productName;
		this.productQuantity = productQuantity;
		this.productPrice = productPrice;
		this.productCategory = productCategory;
		this.productImage = productImage;
		this.productUser = productUser;
	}
	
	//Getter and Setter
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	@Column(length=20)
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}

	
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}


	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	
	@Column(name="Image",nullable=true, length=Integer.MAX_VALUE)
	public String getproductImage() {
		return productImage;
	}

	public void setproductImage(String path) {
		
		this.productImage = path;
	}


	public CommonsMultipartFile getFileData() {
	return fileData;
	}

	public void setFileData(CommonsMultipartFile fileData) {
	this.fileData = fileData;
	}
/*	public String getBase64() {
		if(base64 == null){
		try{
			 base64 = new String(Base64.getEncoder().encode(productImage),"UTF-8");
		}catch(Exception e){
			System.out.println("Image reading failed");
		}}
		return base64;
	}

	public void setBase64(String base64) {
		this.base64 = base64;
	}*/
	public String getProductUser() {
		return productUser;
	}
	public void setProductUser(String productUser) {
		this.productUser = productUser;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", sellerId=" + sellerId + ", productName=" + productName
				+ ", productImage=" + productImage + "]";
	}
	
	//to String 
	/*@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productQuantity="
				+ productQuantity + ", productPrice=" + productPrice + ", productCategory=" + productCategory
				+ ", sellerId=" + sellerId + ", productImage=" + productImage + ", productUser=" + productUser + "]";
	}*/
	

}
